package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"

	"backendLMS/repositories"
)

func SubmitStudentAnswer(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	attemptID, _ := strconv.ParseInt(vars["id"], 10, 64)

	var req struct {
		QuestionBankID int64 `json:"question_bank_id"`
		AnswerBankID   int64 `json:"answer_bank_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid body", http.StatusBadRequest)
		return
	}

	ans, err := repositories.SubmitAnswer(r.Context(), attemptID, req.QuestionBankID, req.AnswerBankID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(ans)
}

func GetAttemptAnswers(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	attemptID, _ := strconv.ParseInt(vars["id"], 10, 64)

	answers, err := repositories.GetAnswersByAttemptID(r.Context(), attemptID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(answers)
}
