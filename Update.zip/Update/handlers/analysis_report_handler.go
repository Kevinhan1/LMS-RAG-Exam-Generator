package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"

	"backendLMS/repositories"
)

func GetQuizReports(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)

	reports, err := repositories.GetReportsByQuiz(r.Context(), quizID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(reports)
}

func GetIndividualStudentReport(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)
	studentID, _ := strconv.ParseInt(vars["student_id"], 10, 64)

	report, err := repositories.GetIndividualReport(r.Context(), quizID, studentID)
	if err != nil {
		http.Error(w, "Report not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(report)
}
