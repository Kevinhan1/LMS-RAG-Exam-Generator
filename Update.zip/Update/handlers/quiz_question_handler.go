package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"

	"backendLMS/repositories"
)

func AddQuizQuestion(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)

	var req struct {
		QuestionBankID int64 `json:"question_bank_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid body", http.StatusBadRequest)
		return
	}

	if err := repositories.AddQuestionToQuiz(r.Context(), quizID, req.QuestionBankID); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func GetQuizQuestions(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)

	questions, err := repositories.GetQuizQuestions(r.Context(), quizID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(questions)
}

func RemoveQuizQuestion(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, _ := strconv.ParseInt(vars["id"], 10, 64)

	if err := repositories.RemoveQuestionFromQuiz(r.Context(), id); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

func UpdateQuizQuestionOrder(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, _ := strconv.ParseInt(vars["id"], 10, 64)

	var req struct {
		OrderNo int `json:"order_no"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid body", http.StatusBadRequest)
		return
	}

	if err := repositories.UpdateQuizQuestionOrder(r.Context(), id, req.OrderNo); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}
