package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"

	"backendLMS/middlewares"
	"backendLMS/repositories"
)

func StartAttempt(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)
	userID, _ := r.Context().Value(middlewares.CtxUserID).(int64)

	attempt, err := repositories.StartAttempt(r.Context(), userID, quizID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(attempt)
}

func FinishAttempt(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, _ := strconv.ParseInt(vars["id"], 10, 64)

	var req struct {
		FinalScore float64 `json:"final_score"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid body", http.StatusBadRequest)
		return
	}

	if err := repositories.FinishAttempt(r.Context(), id, req.FinalScore); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func GetStudentQuizAttempts(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	quizID, _ := strconv.ParseInt(vars["quiz_id"], 10, 64)
	userID, _ := r.Context().Value(middlewares.CtxUserID).(int64)

	attempts, err := repositories.GetStudentQuizAttempts(r.Context(), userID, quizID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(attempts)
}

func GetAttemptByID(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, _ := strconv.ParseInt(vars["id"], 10, 64)

	attempt, err := repositories.GetAttemptByID(r.Context(), id)
	if err != nil {
		http.Error(w, "Attempt not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(attempt)
}
