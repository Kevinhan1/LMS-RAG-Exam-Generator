package repositories

import (
	"context"
	"time"

	"backendLMS/db"
	"backendLMS/models"
)

func SaveAnalysisReport(ctx context.Context, quizID int64, studentID *int64, reportType string, aiFeedback any) error {
	now := time.Now().Unix()
	_, err := db.Pool.Exec(ctx, `
		INSERT INTO analysis_reports (quiz_id, student_id, report_type, ai_feedback, timecreated, timemodified)
		VALUES ($1, $2, $3, $4, $5, $5)
		ON CONFLICT ON CONSTRAINT analysis_reports_pkey DO UPDATE 
		SET ai_feedback = EXCLUDED.ai_feedback, timemodified = EXCLUDED.timemodified
	`, quizID, studentID, reportType, aiFeedback, now)
	return err
}

func GetReportsByQuiz(ctx context.Context, quizID int64) ([]models.AnalysisReport, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT id, quiz_id, student_id, report_type, ai_feedback, timecreated, timemodified
		FROM analysis_reports
		WHERE quiz_id = $1
	`, quizID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var reports []models.AnalysisReport
	for rows.Next() {
		var r models.AnalysisReport
		if err := rows.Scan(&r.ID, &r.QuizID, &r.StudentID, &r.ReportType, &r.AIFeedback, &r.TimeCreated, &r.TimeModified); err != nil {
			return nil, err
		}
		reports = append(reports, r)
	}
	return reports, nil
}

func GetIndividualReport(ctx context.Context, quizID, studentID int64) (*models.AnalysisReport, error) {
	var r models.AnalysisReport
	err := db.Pool.QueryRow(ctx, `
		SELECT id, quiz_id, student_id, report_type, ai_feedback, timecreated, timemodified
		FROM analysis_reports
		WHERE quiz_id = $1 AND student_id = $2 AND report_type = 'individual'
	`, quizID, studentID).Scan(&r.ID, &r.QuizID, &r.StudentID, &r.ReportType, &r.AIFeedback, &r.TimeCreated, &r.TimeModified)

	if err != nil {
		return nil, err
	}
	return &r, nil
}
