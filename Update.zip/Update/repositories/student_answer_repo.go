package repositories

import (
	"context"
	"errors"
	"time"

	"backendLMS/db"
	"backendLMS/models"
)

func SubmitAnswer(ctx context.Context, attemptID, questionBankID, answerBankID int64) (*models.StudentAnswer, error) {
	// 1. Validate if the answer belongs to the question
	var isCorrect bool
	var qbID int64
	err := db.Pool.QueryRow(ctx, `
		SELECT is_correct, question_bank_id FROM answer_bank WHERE id = $1
	`, answerBankID).Scan(&isCorrect, &qbID)

	if err != nil {
		return nil, errors.New("answer option not found")
	}

	if qbID != questionBankID {
		return nil, errors.New("answer does not belong to the specified question")
	}

	// 2. Insert or update the student's answer
	now := time.Now()
	var sa models.StudentAnswer
	err = db.Pool.QueryRow(ctx, `
		INSERT INTO student_answers (attempt_id, question_bank_id, answer_bank_id, is_correct, submitted_at)
		VALUES ($1, $2, $3, $4, $5)
		ON CONFLICT (attempt_id, question_bank_id) DO UPDATE 
		SET answer_bank_id = EXCLUDED.answer_bank_id, 
		    is_correct = EXCLUDED.is_correct, 
		    submitted_at = EXCLUDED.submitted_at
		RETURNING id, attempt_id, question_bank_id, answer_bank_id, is_correct, submitted_at
	`, attemptID, questionBankID, answerBankID, isCorrect, now).Scan(&sa.ID, &sa.AttemptID, &sa.QuestionBankID, &sa.AnswerBankID, &sa.IsCorrect, &sa.SubmittedAt)

	if err != nil {
		// If ON CONFLICT doesn't work (no unique constraint yet maybe), we might need to handle it manually or add the constraint
		// Based on the schema provided, there is no UNIQUE constraint on (attempt_id, question_bank_id)
		// Let's check for an existing answer and update, or just insert if we want to allow multiple (usually 1 per question)
		
		// If the user didn't specify a unique constraint in the SQL they sent, I should probably check first
		// But usually it's one answer per question per attempt.
		return nil, err
	}

	return &sa, nil
}

func GetAnswersByAttemptID(ctx context.Context, attemptID int64) ([]models.StudentAnswer, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT id, attempt_id, question_bank_id, answer_bank_id, is_correct, submitted_at
		FROM student_answers
		WHERE attempt_id = $1
	`, attemptID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []models.StudentAnswer
	for rows.Next() {
		var sa models.StudentAnswer
		if err := rows.Scan(&sa.ID, &sa.AttemptID, &sa.QuestionBankID, &sa.AnswerBankID, &sa.IsCorrect, &sa.SubmittedAt); err != nil {
			return nil, err
		}
		result = append(result, sa)
	}
	return result, nil
}

func GetAttemptAnswersForAnalysis(ctx context.Context, attemptID int64) ([]map[string]interface{}, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT qb.content, ab.option_text as student_answer, 
		       (SELECT option_text FROM answer_bank WHERE question_bank_id = qb.id AND is_correct = true LIMIT 1) as correct_answer,
		       sa.is_correct
		FROM student_answers sa
		JOIN question_bank qb ON sa.question_bank_id = qb.id
		JOIN answer_bank ab ON sa.answer_bank_id = ab.id
		WHERE sa.attempt_id = $1
	`, attemptID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []map[string]interface{}
	for rows.Next() {
		var content, studentAns, correctAns string
		var isCorrect bool
		if err := rows.Scan(&content, &studentAns, &correctAns, &isCorrect); err != nil {
			return nil, err
		}
		result = append(result, map[string]interface{}{
			"question":       content,
			"student_answer": studentAns,
			"correct_answer": correctAns,
			"is_correct":     isCorrect,
		})
	}
	return result, nil
}

