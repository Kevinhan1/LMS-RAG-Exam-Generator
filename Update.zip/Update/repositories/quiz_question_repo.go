package repositories

import (
	"context"
	"time"

	"backendLMS/db"
	"backendLMS/models"
)

func AddQuestionToQuiz(ctx context.Context, quizID, questionBankID int64) error {
	now := time.Now().Unix()
	
	// Get current max order_no
	var maxOrder int
	err := db.Pool.QueryRow(ctx, "SELECT COALESCE(MAX(order_no), 0) FROM quiz_questions WHERE quiz_id = $1", quizID).Scan(&maxOrder)
	if err != nil {
		return err
	}

	_, err = db.Pool.Exec(ctx, `
		INSERT INTO quiz_questions (quiz_id, question_bank_id, order_no, timecreated, timemodified)
		VALUES ($1, $2, $3, $4, $4)
	`, quizID, questionBankID, maxOrder+1, now)
	
	return err
}

func GetQuizQuestions(ctx context.Context, quizID int64) ([]models.QuizQuestion, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT id, quiz_id, question_bank_id, order_no, timecreated, timemodified
		FROM quiz_questions
		WHERE quiz_id = $1
		ORDER BY order_no ASC
	`, quizID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var result []models.QuizQuestion
	for rows.Next() {
		var qq models.QuizQuestion
		if err := rows.Scan(&qq.ID, &qq.QuizID, &qq.QuestionBankID, &qq.OrderNo, &qq.TimeCreated, &qq.TimeModified); err != nil {
			return nil, err
		}
		result = append(result, qq)
	}
	return result, nil
}

func RemoveQuestionFromQuiz(ctx context.Context, id int64) error {
	_, err := db.Pool.Exec(ctx, "DELETE FROM quiz_questions WHERE id = $1", id)
	return err
}

func UpdateQuizQuestionOrder(ctx context.Context, id int64, orderNo int) error {
	now := time.Now().Unix()
	_, err := db.Pool.Exec(ctx, "UPDATE quiz_questions SET order_no = $1, timemodified = $2 WHERE id = $3", orderNo, now, id)
	return err
}
