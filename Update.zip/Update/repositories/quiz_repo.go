package repositories

import (
	"context"
	"time"

	"backendLMS/db"
	"backendLMS/models"
	"errors"
)

func IsValidQuizType(t string) bool {
	switch t {
	case "Exercise", "Quiz", "Midterm Exam", "Final Exam":
		return true
	}
	return false
}


func GetAllQuizzes(ctx context.Context, teacherID int64, roleID int) ([]models.Quiz, error) {
	var query string
	var args []interface{}

	if roleID == 1 { // ADMIN
		query = `SELECT id, teacher_id, course_id, title, description, type, start_time, end_time, timecreated, timemodified FROM quizzes ORDER BY timecreated DESC`
	} else { // TEACHER
		query = `SELECT id, teacher_id, course_id, title, description, type, start_time, end_time, timecreated, timemodified FROM quizzes WHERE teacher_id = $1 ORDER BY timecreated DESC`
		args = append(args, teacherID)
	}

	rows, err := db.Pool.Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var quizzes []models.Quiz
	for rows.Next() {
		var q models.Quiz
		err := rows.Scan(&q.ID, &q.TeacherID, &q.CourseID, &q.Title, &q.Description, &q.Type, &q.StartTime, &q.EndTime, &q.TimeCreated, &q.TimeModified)
		if err != nil {
			return nil, err
		}
		quizzes = append(quizzes, q)
	}

	return quizzes, nil
}

func GetQuizByID(ctx context.Context, id int64) (*models.Quiz, error) {
	var q models.Quiz
	err := db.Pool.QueryRow(ctx, `
		SELECT id, teacher_id, course_id, title, description, type, start_time, end_time, timecreated, timemodified 
		FROM quizzes WHERE id = $1
	`, id).Scan(&q.ID, &q.TeacherID, &q.CourseID, &q.Title, &q.Description, &q.Type, &q.StartTime, &q.EndTime, &q.TimeCreated, &q.TimeModified)

	if err != nil {
		return nil, err
	}

	return &q, nil
}

func CreateQuiz(ctx context.Context, q *models.Quiz) error {
	if !IsValidQuizType(q.Type) {
		return errors.New("invalid quiz type: must be Exercise, Quiz, Midterm Exam, or Final Exam")
	}

	now := time.Now().Unix()

	err := db.Pool.QueryRow(ctx, `
		INSERT INTO quizzes (teacher_id, course_id, title, description, type, start_time, end_time, timecreated, timemodified)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8)
		RETURNING id
	`, q.TeacherID, q.CourseID, q.Title, q.Description, q.Type, q.StartTime, q.EndTime, now).Scan(&q.ID)

	if err != nil {
		return err
	}

	q.TimeCreated = now
	q.TimeModified = now
	return nil
}

func UpdateQuiz(ctx context.Context, q *models.Quiz) error {
	if !IsValidQuizType(q.Type) {
		return errors.New("invalid quiz type: must be Exercise, Quiz, Midterm Exam, or Final Exam")
	}

	now := time.Now().Unix()

	_, err := db.Pool.Exec(ctx, `
		UPDATE quizzes 
		SET title = $1, description = $2, type = $3, start_time = $4, end_time = $5, timemodified = $6
		WHERE id = $7
	`, q.Title, q.Description, q.Type, q.StartTime, q.EndTime, now, q.ID)

	if err != nil {
		return err
	}

	q.TimeModified = now
	return nil
}

func DeleteQuiz(ctx context.Context, id int64) error {
	_, err := db.Pool.Exec(ctx, `DELETE FROM quizzes WHERE id = $1`, id)
	return err
}
