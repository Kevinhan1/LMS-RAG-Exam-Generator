package repositories

import (
	"backendLMS/db"
	"backendLMS/models"
	"context"
)

func CreateUser(ctx context.Context, u *models.User) error {
	sql := `
	INSERT INTO users
	(name,email,password_hash,role_id,class_id,nisn,nip,timecreated)
	VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
	RETURNING id
	`
	return db.Pool.QueryRow(
		ctx, sql,
		u.Name,
		u.Email,
		u.PasswordHash,
		u.RoleID,
		u.ClassID,
		u.NISN,
		u.NIP,
		u.TimeCreated,
	).Scan(&u.ID)
}

func GetUserByID(ctx context.Context, userID int64) (*models.User, error) {
	sql := `
	SELECT id, name, email, role_id, class_id, nisn, nip, timecreated
	FROM users WHERE id=$1
	`
	var u models.User
	err := db.Pool.QueryRow(ctx, sql, userID).
		Scan(&u.ID, &u.Name, &u.Email, &u.RoleID, &u.ClassID, &u.NISN, &u.NIP, &u.TimeCreated)
	return &u, err
}

func GetUserByEmail(ctx context.Context, email string) (*models.User, error) {
	sql := `
	SELECT id, name, email, password_hash, role_id, class_id, nisn, nip, timecreated
	FROM users WHERE email=$1
	`
	var u models.User
	err := db.Pool.QueryRow(ctx, sql, email).
		Scan(&u.ID, &u.Name, &u.Email, &u.PasswordHash, &u.RoleID, &u.ClassID, &u.NISN, &u.NIP, &u.TimeCreated)
	return &u, err
}

func GetUserName(ctx context.Context, userID int64) (string, error) {
	var name string
	err := db.Pool.QueryRow(ctx, "SELECT name FROM users WHERE id=$1", userID).Scan(&name)
	return name, err
}

