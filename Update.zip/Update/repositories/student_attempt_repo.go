package repositories

import (
	"context"
	"time"

	"backendLMS/db"
	"backendLMS/models"
)

func StartAttempt(ctx context.Context, studentID, quizID int64) (*models.StudentAttempt, error) {
	now := time.Now()
	var attempt models.StudentAttempt
	err := db.Pool.QueryRow(ctx, `
		INSERT INTO student_attempts (student_id, quiz_id, start_time, finished)
		VALUES ($1, $2, $3, false)
		RETURNING id, student_id, quiz_id, start_time, finished
	`, studentID, quizID, now).Scan(&attempt.ID, &attempt.StudentID, &attempt.QuizID, &attempt.StartTime, &attempt.Finished)

	if err != nil {
		return nil, err
	}

	return &attempt, nil
}

func GetAttemptByID(ctx context.Context, id int64) (*models.StudentAttempt, error) {
	var a models.StudentAttempt
	err := db.Pool.QueryRow(ctx, `
		SELECT id, student_id, quiz_id, start_time, end_time, final_score, finished
		FROM student_attempts
		WHERE id = $1
	`, id).Scan(&a.ID, &a.StudentID, &a.QuizID, &a.StartTime, &a.EndTime, &a.FinalScore, &a.Finished)

	if err != nil {
		return nil, err
	}

	return &a, nil
}

func GetStudentQuizAttempts(ctx context.Context, studentID, quizID int64) ([]models.StudentAttempt, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT id, student_id, quiz_id, start_time, end_time, final_score, finished
		FROM student_attempts
		WHERE student_id = $1 AND quiz_id = $2
		ORDER BY start_time DESC
	`, studentID, quizID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var attempts []models.StudentAttempt
	for rows.Next() {
		var a models.StudentAttempt
		if err := rows.Scan(&a.ID, &a.StudentID, &a.QuizID, &a.StartTime, &a.EndTime, &a.FinalScore, &a.Finished); err != nil {
			return nil, err
		}
		attempts = append(attempts, a)
	}
	return attempts, nil
}

func FinishAttempt(ctx context.Context, id int64, score float64) error {
	now := time.Now()
	_, err := db.Pool.Exec(ctx, `
		UPDATE student_attempts
		SET end_time = $1, final_score = $2, finished = true
		WHERE id = $3
	`, now, score, id)
	return err
}

func GetQuizAttempts(ctx context.Context, quizID int64) ([]models.StudentAttempt, error) {
	rows, err := db.Pool.Query(ctx, `
		SELECT id, student_id, quiz_id, start_time, end_time, final_score, finished
		FROM student_attempts
		WHERE quiz_id = $1
	`, quizID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var attempts []models.StudentAttempt
	for rows.Next() {
		var a models.StudentAttempt
		if err := rows.Scan(&a.ID, &a.StudentID, &a.QuizID, &a.StartTime, &a.EndTime, &a.FinalScore, &a.Finished); err != nil {
			return nil, err
		}
		attempts = append(attempts, a)
	}
	return attempts, nil
}

