package router

import (
	"net/http"

	"backendLMS/handlers"
	"backendLMS/middlewares"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
)

// New
func New() http.Handler {
	r := mux.NewRouter()

	// PUBLIC ROUTES
	r.HandleFunc("/register", handlers.Register).Methods("POST")
	r.HandleFunc("/login", handlers.Login).Methods("POST")

	r.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("ok"))
	}).Methods("GET")

	// Public classes endpoint (no auth required)
	r.HandleFunc("/api/classes", handlers.GetClasses).Methods("GET")
	r.HandleFunc("/api/classes/{id}", handlers.GetClassByID).Methods("GET")

	// PROTECTED ROUTES (JWT)
	api := r.PathPrefix("/api").Subrouter()
	api.Use(middlewares.JWTAuth)

	// COMMON USER
	api.HandleFunc("/me", handlers.Me).Methods("GET")

	// TEACHER ONLY ROUTES

	// (permission-based check)
	teacher := api.PathPrefix("/teacher").Subrouter()

	// ---- Course Access Validation
	teacher.HandleFunc("/courses/{id}/validate-access", handlers.ValidateTeacherCourseAccess).Methods("GET")

	// ---- Chapter Access Validation
	teacher.HandleFunc("/chapters/{id}/validate-access", handlers.ValidateTeacherChapterAccess).Methods("GET")

	// ---- RAG Question Generation
	teacher.HandleFunc("/questions/rag_generate", handlers.GenerateQuestionFromRAG).Methods("POST")

	// --- Question Management permission check
	teacher.HandleFunc("/questions", handlers.GetQuestions).Methods("GET")
	teacher.HandleFunc("/questions/{id}", handlers.GetQuestionDetail).Methods("GET")
	teacher.HandleFunc("/questions", handlers.CreateQuestion).Methods("POST")
	teacher.HandleFunc("/questions/{id}", handlers.UpdateQuestion).Methods("PUT")
	teacher.HandleFunc("/questions/{id}", handlers.DeleteQuestion).Methods("DELETE")

	// ---- Answer Management permission check
	teacher.HandleFunc("/questions/{id}/answers", handlers.CreateAnswer).Methods("POST")
	teacher.HandleFunc("/answers/{id}", handlers.UpdateAnswer).Methods("PUT")
	teacher.HandleFunc("/answers/{id}", handlers.DeleteAnswer).Methods("DELETE")

	// ---- Quiz Management
	teacher.HandleFunc("/quizzes", handlers.GetQuizzes).Methods("GET")
	teacher.HandleFunc("/quizzes/{id}", handlers.GetQuizDetail).Methods("GET")
	teacher.HandleFunc("/quizzes", handlers.CreateQuiz).Methods("POST")
	teacher.HandleFunc("/quizzes/{id}", handlers.UpdateQuiz).Methods("PUT")
	teacher.HandleFunc("/quizzes/{id}", handlers.DeleteQuiz).Methods("DELETE")

	// ---- Quiz Questions Management
	teacher.HandleFunc("/quizzes/{quiz_id}/questions", handlers.GetQuizQuestions).Methods("GET")
	teacher.HandleFunc("/quizzes/{quiz_id}/questions", handlers.AddQuizQuestion).Methods("POST")
	teacher.HandleFunc("/quiz-questions/{id}", handlers.RemoveQuizQuestion).Methods("DELETE")
	teacher.HandleFunc("/quiz-questions/{id}/order", handlers.UpdateQuizQuestionOrder).Methods("PATCH")

	// ---- Analysis Report Management
	teacher.HandleFunc("/quizzes/{quiz_id}/reports", handlers.GetQuizReports).Methods("GET")
	teacher.HandleFunc("/quizzes/{quiz_id}/reports/individual/{student_id}", handlers.GetIndividualStudentReport).Methods("GET")




	// ---- Chapter Management permission check
	teacher.Handle(
		"/chapters",
		middlewares.RequirePermissions("manage_chapters")(
			http.HandlerFunc(handlers.CreateChapterHandler),
		),
	).Methods("POST")

	teacher.Handle(
		"/chapters/{id}",
		middlewares.RequirePermissions("manage_chapters")(
			http.HandlerFunc(handlers.UpdateChapterHandler),
		),
	).Methods("PUT")

	teacher.Handle(
		"/chapters/{id}",
		middlewares.RequirePermissions("manage_chapters")(
			http.HandlerFunc(handlers.DeleteChapterHandler),
		),
	).Methods("DELETE")

	// ---- Material Management dengan permission check
	teacher.Handle(
		"/material",
		middlewares.RequirePermissions("upload_material")(
			http.HandlerFunc(handlers.CreateMaterial),
		),
	).Methods("POST")

	teacher.Handle(
		"/materials/{id}",
		middlewares.RequirePermissions("edit_material")(
			http.HandlerFunc(handlers.TeacherUpdateMaterial),
		),
	).Methods("PUT")

	teacher.Handle(
		"/materials/{id}",
		middlewares.RequirePermissions("delete_material")(
			http.HandlerFunc(handlers.TeacherDeleteMaterial),
		),
	).Methods("DELETE")

	// Admin routes (role-based check)
	admin := api.PathPrefix("/admin").Subrouter()
	admin.Use(middlewares.RequireRoles(1))

	// ---- Role Management
	admin.HandleFunc("/roles", handlers.GetRoles).Methods("GET")
	admin.HandleFunc("/roles", handlers.CreateRole).Methods("POST")
	admin.HandleFunc("/roles/{id}", handlers.GetRole).Methods("GET")
	admin.HandleFunc("/roles/{id}", handlers.UpdateRole).Methods("PUT")
	admin.HandleFunc("/roles/{id}", handlers.DeleteRole).Methods("DELETE")

	// ---- Role-Permission Management (TAMBAHAN BARU)
	admin.HandleFunc("/roles/{id}/permissions", handlers.GetRolePermissions).Methods("GET")
	admin.HandleFunc("/roles/{id}/permissions", handlers.AssignPermission).Methods("POST")
	admin.HandleFunc("/roles/{id}/permissions/{permission_id}", handlers.RemovePermission).Methods("DELETE")

	// ---- Permission Management
	admin.HandleFunc("/permissions", handlers.GetPermissions).Methods("GET")
	admin.HandleFunc("/permissions", handlers.CreatePermission).Methods("POST")
	admin.HandleFunc("/permissions/{id}", handlers.GetPermission).Methods("GET")
	admin.HandleFunc("/permissions/{id}", handlers.UpdatePermission).Methods("PUT")
	admin.HandleFunc("/permissions/{id}", handlers.DeletePermission).Methods("DELETE")

	// ---- User Management
	admin.HandleFunc("/users", handlers.GetUsers).Methods("GET")
	admin.HandleFunc("/users/{id}", handlers.UpdateUser).Methods("PUT")
	admin.HandleFunc("/users/{id}", handlers.DeleteUser).Methods("DELETE")

	// ---- Register Users
	admin.HandleFunc("/register/student", handlers.RegisterStudent).Methods("POST")
	admin.HandleFunc("/register/teacher", handlers.RegisterTeacher).Methods("POST")

	// ---- Class Management
	admin.HandleFunc("/classes", handlers.CreateClass).Methods("POST")
	admin.HandleFunc("/classes/{id}", handlers.UpdateClass).Methods("PUT")
	admin.HandleFunc("/classes/{id}", handlers.DeleteClass).Methods("DELETE")

	// ---- Course Management (CRUD)
	admin.HandleFunc("/courses", handlers.CreateCourse).Methods("POST")
	admin.HandleFunc("/courses/{id}", handlers.UpdateCourse).Methods("PUT")
	admin.HandleFunc("/courses/{id}", handlers.DeleteCourse).Methods("DELETE")

	// ---- Course-Class Management (Enrollment)
	admin.HandleFunc("/courses/{id}/enroll-class", handlers.EnrollEntireClass).Methods("POST")
	admin.HandleFunc("/courses/{id}/classes/{class_id}/unenroll", handlers.UnenrollEntireClass).Methods("DELETE")
	admin.HandleFunc("/courses/{id}/available-classes", handlers.GetAvailableClasses).Methods("GET")

	// ---- Course-Teacher Management (Enrollment)
	admin.HandleFunc("/courses/{id}/enroll-teacher", handlers.EnrollTeacherToCourse).Methods("POST")
	admin.HandleFunc("/courses/{id}/teachers/{teacher_id}/unenroll", handlers.UnenrollTeacherFromCourse).Methods("DELETE")
	admin.HandleFunc("/courses/{id}/available-teachers", handlers.GetAvailableTeachersForCourse).Methods("GET")

	// ---- Chapter Management (CRUD)
	admin.HandleFunc("/chapters", handlers.CreateChapterHandler).Methods("POST")
	admin.HandleFunc("/chapters/{id}", handlers.UpdateChapterHandler).Methods("PUT")
	admin.HandleFunc("/chapters/{id}", handlers.DeleteChapterHandler).Methods("DELETE")

	// ---- Tag Management (CRUD)
	admin.HandleFunc("/tags", handlers.CreateTagHandler).Methods("POST")
	admin.HandleFunc("/tags/{id}", handlers.UpdateTagHandler).Methods("PUT")
	admin.HandleFunc("/tags/{id}", handlers.DeleteTagHandler).Methods("DELETE")

	// ---- Material Management (CRUD)
	admin.HandleFunc("/materials", handlers.CreateMaterial).Methods("POST")
	admin.HandleFunc("/materials/{id}", handlers.UpdateMaterial).Methods("PUT")
	admin.HandleFunc("/materials/{id}", handlers.DeleteMaterial).Methods("DELETE")

	// ---- Material Tags (RESTful - nested under materials)
	admin.HandleFunc("/materials/{id}/tags", handlers.AttachTagToMaterial).Methods("POST")
	admin.HandleFunc("/materials/{id}/tags/{tag_id}", handlers.DetachMaterialTag).Methods("DELETE")

	// ---- Question Management
	admin.HandleFunc("/questions", handlers.GetQuestions).Methods("GET")
	admin.HandleFunc("/questions/{id}", handlers.GetQuestionDetail).Methods("GET")
	admin.HandleFunc("/questions", handlers.CreateQuestion).Methods("POST") // Jika perlu
	admin.HandleFunc("/questions/{id}", handlers.UpdateQuestion).Methods("PUT")
	admin.HandleFunc("/questions/{id}", handlers.DeleteQuestion).Methods("DELETE")
	admin.HandleFunc("/questions/{id}/status", handlers.UpdateQuestionStatus).Methods("PATCH")

	// ---- Answer Management
	admin.HandleFunc("/questions/{id}/answers", handlers.CreateAnswer).Methods("POST")
	admin.HandleFunc("/answers/{id}", handlers.UpdateAnswer).Methods("PUT")
	admin.HandleFunc("/answers/{id}", handlers.DeleteAnswer).Methods("DELETE")

	// ---- Quiz Management
	admin.HandleFunc("/quizzes", handlers.GetQuizzes).Methods("GET")
	admin.HandleFunc("/quizzes/{id}", handlers.GetQuizDetail).Methods("GET")
	admin.HandleFunc("/quizzes", handlers.UpdateQuiz).Methods("PUT")
	admin.HandleFunc("/quizzes/{id}", handlers.DeleteQuiz).Methods("DELETE")

	// ---- Quiz Questions Management
	admin.HandleFunc("/quizzes/{quiz_id}/questions", handlers.GetQuizQuestions).Methods("GET")
	admin.HandleFunc("/quizzes/{quiz_id}/questions", handlers.AddQuizQuestion).Methods("POST")
	admin.HandleFunc("/quiz-questions/{id}", handlers.RemoveQuizQuestion).Methods("DELETE")
	admin.HandleFunc("/quiz-questions/{id}/order", handlers.UpdateQuizQuestionOrder).Methods("PATCH")




	// ---- Log Activity Management
	admin.HandleFunc("/logs", handlers.GetLogs).Methods("GET")

	// PUBLIC / AUTH USERS (Read Only)

	// ---- Courses (Read)
	api.HandleFunc("/courses", handlers.GetCourses).Methods("GET")
	api.HandleFunc("/courses/{id}", handlers.GetCourseByID).Methods("GET")

	// ---- Course-Class Info (Read)
	api.HandleFunc("/courses/{id}/course-classes", handlers.GetCourseClasses).Methods("GET")
	api.HandleFunc("/courses/{id}/course-classes/{class_id}/students", handlers.GetClassStudents).Methods("GET")

	// ---- Course-Teacher Info (Read)
	api.HandleFunc("/courses/{id}/teachers", handlers.GetCourseTeachers).Methods("GET")

	// ---- Chapters (Read)
	api.HandleFunc("/courses/{course_id}/chapters", handlers.GetChaptersHandler).Methods("GET")
	api.HandleFunc("/chapters/{id}", handlers.GetChapterByIDHandler).Methods("GET")

	// ---- Tags (Read)
	api.HandleFunc("/tags", handlers.GetTagsHandler).Methods("GET")
	api.HandleFunc("/tags/{id}", handlers.GetTagByID).Methods("GET")

	// ---- Materials (Read)
	api.HandleFunc("/materials", handlers.GetMaterials).Methods("GET")
	api.HandleFunc("/materials/{id}", handlers.GetMaterialByID).Methods("GET")

	// ---- Material Tags (Read) - RESTful nested endpoint
	api.HandleFunc("/materials/{id}/tags", handlers.GetMaterialTags).Methods("GET")

	// ENROLLMENT (STUDENT ONLY)

	api.Handle(
		"/courses/{id}/enroll",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.EnrollCourse),
		),
	).Methods("POST")

	api.Handle(
		"/courses/{id}/unenroll",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.UnenrollCourse),
		),
	).Methods("DELETE")

	// ---- Student Attempt Management
	api.Handle(
		"/quizzes/{quiz_id}/attempts",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.StartAttempt),
		),
	).Methods("POST")

	api.Handle(
		"/quizzes/{quiz_id}/attempts",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.GetStudentQuizAttempts),
		),
	).Methods("GET")

	api.Handle(
		"/attempts/{id}/finish",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.FinishAttempt),
		),
	).Methods("PUT")

	api.Handle(
		"/attempts/{id}",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.GetAttemptByID),
		),
	).Methods("GET")

	// ---- Student Answer Management
	api.Handle(
		"/attempts/{id}/answers",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.SubmitStudentAnswer),
		),
	).Methods("POST")

	api.Handle(
		"/attempts/{id}/answers",
		middlewares.RequireRoles(3)(
			http.HandlerFunc(handlers.GetAttemptAnswers),
		),
	).Methods("GET")

	api.Handle(
		"/my-courses",
		middlewares.RequireRoles(2, 3)(
			http.HandlerFunc(handlers.MyCourses),
		),
	).Methods("GET")

	// COURSE STUDENTS (TEACHER + ADMIN)

	api.Handle(
		"/courses/{id}/students",
		middlewares.RequireRoles(2, 1)(
			http.HandlerFunc(handlers.GetCourseStudents),
		),
	).Methods("GET")

	// CORS MIDDLEWARE

	c := cors.New(cors.Options{
		AllowedOrigins: []string{
			"http://localhost:3000",
			"http://localhost:3001",
			"http://192.168.7.70:3000",
			"http://192.168.0.12:3000",
		},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Content-Type", "Authorization"},
		AllowCredentials: true,
		Debug:            false, // Enable for debugging
	})

	return c.Handler(r)
}
