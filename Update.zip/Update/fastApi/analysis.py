import json
from llm import ask_llm

def analyze_individual_performance(student_name, quiz_title, answers):
    """
    answers: list of dicts {question: str, student_answer: str, correct_answer: str, is_correct: bool}
    """
    prompt = f"""
    Analisis performa siswa bernama '{student_name}' dalam quiz '{quiz_title}'.
    
    Detail Jawaban:
    {json.dumps(answers, indent=2, ensure_ascii=False)}
    
    Berikan evaluasi pedagogis dalam BAHASA INDONESIA:
    1. Kelebihan: di mana siswa menunjukkan performa yang baik.
    2. Kekurangan: area atau topik spesifik yang perlu diperbaiki.
    3. Rekomendasi: langkah nyata yang bisa dilakukan siswa untuk meningkatkan kemampuannya.
    
    Kembalikan respon dalam format JSON:
    {{
        "strengths": "...",
        "weaknesses": "...",
        "recommendations": "..."
    }}
    
    WAJIB menggunakan Bahasa Indonesia untuk isi evaluasi.
    """
    
    response = ask_llm("Anda adalah asisten pendidikan yang membantu dan profesional.", prompt)
    try:
        clean_json = response.strip()
        if clean_json.startswith("```json"):
            clean_json = clean_json[7:-3].strip()
        return json.loads(clean_json)
    except:
        return {"raw_response": response}

def analyze_collective_performance(quiz_title, individual_evaluations):
    """
    individual_evaluations: list of dicts {student_name: str, evaluation: dict}
    """
    prompt = f"""
    Analisis performa keseluruhan kelas untuk quiz '{quiz_title}'.
    
    Ringkasan evaluasi individu:
    {json.dumps(individual_evaluations, indent=2, ensure_ascii=False)}
    
    Berikan evaluasi pedagogis kolektif dalam BAHASA INDONESIA:
    1. Pemahaman Keseluruhan: apa yang umumnya sudah dipahami oleh kelas.
    2. Kesenjangan Umum (Common Gaps): topik-topik di mana banyak siswa merasa kesulitan.
    3. Rekomendasi Kelas: bagaimana guru dapat menyesuaikan pengajaran untuk kelompok ini.
    
    Kembalikan respon dalam format JSON:
    {{
        "overall_understanding": "...",
        "common_gaps": "...",
        "class_recommendations": "..."
    }}
    
    WAJIB menggunakan Bahasa Indonesia untuk isi evaluasi.
    """
    
    response = ask_llm("Anda adalah asisten pendidikan yang fokus pada analisis tingkat kelas.", prompt)
    try:
        clean_json = response.strip()
        if clean_json.startswith("```json"):
            clean_json = clean_json[7:-3].strip()
        return json.loads(clean_json)
    except:
        return {"raw_response": response}
