package main

import (
	"log"
	"net/http"
	"os"

	"backendLMS/db"
	"backendLMS/router"
	"backendLMS/services"

	"github.com/joho/godotenv"
)

func main() {
	// load env
	if err := godotenv.Load(); err != nil {
		// log.Println("No .env file found")
	} else {
		// log.Println(".env loaded")
	}

	// log.Printf(" FASTAPI_URL: %s", os.Getenv("FASTAPI_URL"))
	// log.Printf(" PORT: %s", os.Getenv("PORT"))

	// init database pool
	db.Init()
	defer db.Pool.Close()

	// start background worker
	services.StartAnalysisWorker()


	// init router
	r := router.New()

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Server running on port %s", port)
	log.Fatal(http.ListenAndServe("0.0.0.0:"+port, r))
}
