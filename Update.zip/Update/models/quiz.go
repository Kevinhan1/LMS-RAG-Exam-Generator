package models

import "time"

type Quiz struct {
	ID           int64      `json:"id"`
	TeacherID    int64      `json:"teacher_id"`
	CourseID     int64      `json:"course_id"`
	Title        string     `json:"title"`
	Description  string     `json:"description"`
	Type         string     `json:"type"`
	StartTime    *time.Time `json:"start_time"`
	EndTime      *time.Time `json:"end_time"`
	TimeCreated  int64      `json:"timecreated"`
	TimeModified int64      `json:"timemodified"`
}
