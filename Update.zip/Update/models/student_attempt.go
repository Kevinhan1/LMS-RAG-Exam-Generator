package models

import "time"

type StudentAttempt struct {
	ID         int64      `json:"id"`
	StudentID  int64      `json:"student_id"`
	QuizID     int64      `json:"quiz_id"`
	StartTime  *time.Time `json:"start_time"`
	EndTime    *time.Time `json:"end_time"`
	FinalScore float64    `json:"final_score"`
	Finished   bool       `json:"finished"`
}
