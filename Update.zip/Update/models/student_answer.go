package models

import "time"

type StudentAnswer struct {
	ID             int64     `json:"id"`
	AttemptID      int64     `json:"attempt_id"`
	QuestionBankID int64     `json:"question_bank_id"`
	AnswerBankID   int64     `json:"answer_bank_id"`
	IsCorrect      bool      `json:"is_correct"`
	SubmittedAt    time.Time `json:"submitted_at"`
}
