package models

type QuizQuestion struct {
	ID             int64 `json:"id"`
	QuizID         int64 `json:"quiz_id"`
	QuestionBankID int64 `json:"question_bank_id"`
	OrderNo        int   `json:"order_no"`
	TimeCreated    int64 `json:"timecreated"`
	TimeModified   int64 `json:"timemodified"`
}
