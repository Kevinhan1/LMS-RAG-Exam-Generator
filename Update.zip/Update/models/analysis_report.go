package models

type AnalysisReport struct {
	ID           int64  `json:"id"`
	QuizID       int64  `json:"quiz_id"`
	StudentID    *int64 `json:"student_id,omitempty"` // Null for collective reports
	ReportType   string `json:"report_type"`          // 'individual' or 'collective'
	AIFeedback   any    `json:"ai_feedback"`          // jsonb in DB
	TimeCreated  int64  `json:"timecreated"`
	TimeModified int64  `json:"timemodified"`
}
