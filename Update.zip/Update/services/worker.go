package services

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"time"

	"backendLMS/db"
	"backendLMS/repositories"
)

func StartAnalysisWorker() {
	go func() {
		for {
			ctx := context.Background()
			checkAndTriggerAnalysis(ctx)
			time.Sleep(1 * time.Minute) // Check every minute
		}
	}()
}

func checkAndTriggerAnalysis(ctx context.Context) {
	now := time.Now().Unix()

	// 1. Find quizzes that ended but haven't been analyzed collectively yet
	rows, err := db.Pool.Query(ctx, `
		SELECT q.id, q.title
		FROM quizzes q
		LEFT JOIN analysis_reports ar ON q.id = ar.quiz_id AND ar.report_type = 'collective'
		WHERE q.end_time IS NOT NULL 
		AND EXTRACT(EPOCH FROM q.end_time) <= $1
		AND ar.id IS NULL
	`, now)
	if err != nil {
		log.Printf("[Worker] Error fetching ended quizzes: %v", err)
		return
	}
	defer rows.Close()

	for rows.Next() {
		var quizID int64
		var quizTitle string
		if err := rows.Scan(&quizID, &quizTitle); err != nil {
			continue
		}

		log.Printf("[Worker] Starting analysis for Quiz ID: %d (%s)", quizID, quizTitle)
		processQuizAnalysis(ctx, quizID, quizTitle)
	}
}

func processQuizAnalysis(ctx context.Context, quizID int64, quizTitle string) {
	// 1. Get all students and their answers for this quiz
	attempts, err := repositories.GetQuizAttempts(ctx, quizID) // We need this repo function
	if err != nil {
		log.Printf("[Worker] Error fetching attempts: %v", err)
		return
	}

	fastApiURL := os.Getenv("FASTAPI_URL")
	if fastApiURL == "" {
		fastApiURL = "http://localhost:8000"
	}

	var individualEvals []map[string]interface{}

	for _, att := range attempts {
		if !att.Finished {
			continue
		}

		// Get student name
		studentName, _ := repositories.GetUserName(ctx, att.StudentID) // We need this repo function

		// Get answers and map them for AI
		answers, _ := repositories.GetAttemptAnswersForAnalysis(ctx, att.ID) // We need this repo function

		// Trigger individual analysis via FastAPI
		payload := map[string]interface{}{
			"student_name": studentName,
			"quiz_title":   quizTitle,
			"answers":      answers,
		}
		
		feedback, err := callFastAPI(fastApiURL+"/analyze_performance", payload)
		if err == nil {
			repositories.SaveAnalysisReport(ctx, quizID, &att.StudentID, "individual", feedback)
			individualEvals = append(individualEvals, map[string]interface{}{
				"student_name": studentName,
				"evaluation":   feedback,
			})
		}
	}

	// 2. Trigger collective analysis
	if len(individualEvals) > 0 {
		payload := map[string]interface{}{
			"quiz_title":            quizTitle,
			"individual_evaluations": individualEvals,
		}
		collectiveFeedback, err := callFastAPI(fastApiURL+"/analyze_quiz_overall", payload)
		if err == nil {
			repositories.SaveAnalysisReport(ctx, quizID, nil, "collective", collectiveFeedback)
			log.Printf("[Worker] Successfully completed analysis for Quiz ID: %d", quizID)
		}
	}
}

func callFastAPI(url string, payload interface{}) (interface{}, error) {
	body, _ := json.Marshal(payload)
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("FastAPI error: %d", resp.StatusCode)
	}

	var result interface{}
	json.NewDecoder(resp.Body).Decode(&result)
	return result, nil
}
